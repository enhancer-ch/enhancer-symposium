function fibonacci(n: Int) -> Int {
    if (n == 0) {return 0;}
    if (n == 1) {return 1;}
    
    return fibonacci(n-1) + fibonacci(n-2);
}

print fibonacci(16);
print fibonacci(21);
print fibonacci(22);
