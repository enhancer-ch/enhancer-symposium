---
title: How Rust enables me (you) to create a domain specific language
author: "Jusong Yu"
---

Designing a new language
---

- Language is a system of communication that consists of grammar and vocabulary.
- J. R. R. Tolkien built languages for species cross middle-earth.
- Little languages are everywhere. (YAML, Latex, SQL, XML, JSON, Jinja...)

It is usually not a good idea to invent a new language, only if you have to 

(you'll know it when you get there).

<!-- end_slide -->

Designing a new language
---

I look at programming as having essentially two parts: 
- figuring out what the processor actually needs to do to get something done, 
- and then figuring out the most efficient way to express that in the language I’m using.

-- *Semantic Compression* (Casey Muratori)

<!-- end_slide -->

Why we design a new (workflow) language?
---

- Programming language is how *human* talk to a *machine*. 
- Workflow programming language is an abstraction of how *human* talk to *multiple remote machines* through a machine. 

<!-- column_layout: [1, 1] -->

<!-- column: 0 -->

<!-- pause -->

declaritive workflow (e.g. CWL)

```yaml
dworkflow:
  run: 
    class: ExpressionTool
    inputs: 
      i1: int
    outputs:
      o1: int
    expression: >
      ${return {'o1': inputs.i1 + 1};}
  in:
    i1: i1
  out: [o1]
  requirements:
    cwltool:Loop:
      loopWhen: $(inputs.i1 < 10)
      loop:
        i1: o1
      outputMethod: last
```

<!-- column: 1 -->

<!-- pause -->

imperative:

`python`

```python
def dworkflow(i1):
    while i1 < 10:
        i1 = i1 + 1
    return i1
```

<!-- pause -->

`oxiida`

```c
function dworkflow(i1) {
    while (i1 < 10) {
        i1 = i1 + 1;
    }
    return i1;
}
```

<!-- end_slide -->

A langauge for workflow construction and execution
---

<!-- font_size: 2 -->

- static and strong type system.
- compact domain (e.g. resource management) syntax.
- built-in structured concurrency programming syntax.
- native multi-threading runtime.
- python embedded/embedded in python.


<!-- end_slide -->

basic syntax
---

<!-- column_layout: [1, 1] -->

<!-- column: 0 -->

```c
// basic types, type can be inferred
t: &(String, [Int; 2]) = &("t1", [4, 5]);

// dataclass definition
dataclass MolStructure {
    name: String,
    positions: [[Float; 3]; *],
    kinds: [String; *], 
}

// define a function and customized constructor for CO
function CO(
   c_pos: [Float; 3], 
   o_pos: [Float; 3],
) -> MolStructure {
    mol = MolStructure(
        "C monoxide", 
        [c_pos, o_pos], 
        ["C", "O"],
    );
    return mol;
}
```

<!-- column: 1 -->

```c
// Example CO molecule
co_molecule = CO(
    [0.0000, 0.0000, 0.0000],  // Carbon at origin
    [1.1282, 0.0000, 0.0000],   // Oxygen along x-axis)
);

// Loop through atoms and print them
for idx in [0, 1] {
    idx_str = std::make_string_from_int(idx);
    print "Atom " + idx_str + ": kind=" + co_molecule.kinds[idx] 
          + ", position=" + co_molecule.positions[idx];
}

// Extra: for loop over kinds
for kind in co_molecule.kinds {
    if (kind == "C") {
        print "Carbon atom! — I can do some quantum chemistry!";
    } else {
        print "A" + kind + " atom — check electronegativity?";
    }
}
```

<!-- end_slide -->

recursion
---

<!-- column_layout: [1, 1] -->

<!-- column: 0 -->
`file: fibonacci.ox`

```c
workflow fib(n: Int) -> Int {
    if (n == 0) {return 0;}
    if (n == 1) {return 1;}
    
    return fib(n-1) + fib(n-2);
}

print fib(16);
print fib(21);
print fib(22);
```

<!-- column: 1 -->
```bash +exec
./oxiida run fibonacci.ox
```

<!-- end_slide -->

recursion (data flow)
---

`in: fibonacci.ox`

```c
workflow fib(n: Int) -> Int {
    if (n == 0) {return 0;}
    if (n == 1) {return 1;}
    
    return fib(n-1) + fib(n-2);
}

print fib(3);
```

<!-- pause -->

`out: provenance.csv`

```csv
...
7790-b553-fbe15407b779, node, {"Boolean":true}
7005-aa46-2939fb37a3bb, node, {"Int":1}
79d1-a1ab-8a769ee28907, node, {"Int":2}
7a3e-aa90-f8bbad325770, task, buildin: -
714c-83db-898fbcf85cda, node, {"Int":0}
71c3-9719-a1f0d200af3c, edge, 720f-a321-944e4dc46430 --lhs--> 7a3e-aa90-f8bbad325770
7890-a754-8a75d285da7a, edge, 79d1-a1ab-8a769ee28907 --rhs--> 7a3e-aa90-f8bbad325770
7f83-b0b7-154807720484, edge, 7a3e-aa90-f8bbad325770 --out--> 714c-83db-898fbcf85cda
...
```

<!-- end_slide -->

recursion (data flow: vis)
---

`file: fibonacci.ox`

```c
workflow fib(n: Int) -> Int {
    if (n == 0) {return 0;}
    if (n == 1) {return 1;}
    
    return fib(n-1) + fib(n-2);
}

print fib(3);
```

<!-- pause -->

data flow

![image:width:80%](./provenance-oxiida.png)

<!-- end_slide -->

domain specific syntax 🚧
---
    
- Workflow programming language is an abstraction of how *human* talk to *multiple remote machines* through a machine. 
- Domain specific in having resource management syntax to avoid resource leaking

```c
// Define a machine 
merlin7 = std::MachineSsh(host="merlin7.psi.ch", key="~/.ssh/id_rsa");

// Create a file handler from path
fsrc = std::FileFromPath("/tmp/foobar.txt");

m7file = @machine merlin7 {
    std::run!("whoami");
    o_new = @dir "/home/user/run" {
        // on machine `merlin7` in directory "/home/user/run"
        fo = std::upload_file!(from=fsrc); 
        fo = std::rename_file!(file=fo, name="baz.in");
        fo = std::cp_file!(from=fo, to="baz_new.in");
        run!("echo hello. >> baz_new.in");

        return fo;
    }

    return fo_new;
    // __exit__ scope, close resource handler
}

@dir "/tmp/" {
    // from file in remote -> /tmp/foobar.txt at local
    std::receive_file!(file=m7file, rename="foobar.txt");
}
```

<!-- end_slide -->

Multi-threading runtime
---

<!-- font_size: 2 -->

The language designed for High-throughput workflows.

In this language things runs in **just one** system process.

But, one precss manages > 10,000 tasks concurrently, nothing like python's GIL, it is real multi-threading.

The design is similar to python's multiple interpreter solution for GIL (PEP 545, py3.13).

<!-- end_slide -->

How it looks like (structured concurrency)
---

<!-- skip_slide -->

map, try_map, race, try_race.

<!-- end_slide -->

How?
---

![image:width:80%](./crafting-int.png)

https://craftinginterpreters.com/

<!-- end_slide -->

Rust make it possible and easy
---

It is possible to do this in C/C++, but it will be super hard for a physicist like me.

- Rust's rich type system and ownership model guarantee memory-safety and thread-safety - enabling you to eliminate many classes of bugs at compile-time.
- Writing Rust can feel tough — the compiler often rejects your code. But once it compiles, it’s reliable: no hidden tech debt or silent failures.
- Rust error handling encourages handling errors instead of ignoring them.

Rust has a great ecosystem. 
For building an interpret language, in this project I use:

- `lalrpop` for grammar parsing
- `tokio` for asynchronous runtime
- `pyo3` for FFI to python
- `miette` for fancy error messages

<!-- end_slide -->

Lalrpop for grammar parsing
---

- Iterator of tokens -> syntax tree (full program representation)
- Rules define how tokens combine into higher-level constructs.
- Grammar is specified in a `grammar.lalrpop` file using a BNF-like syntax. 

```lalrpop
// <Expr>   ::= <Expr> "+" <Term> | <Term>

Expr: i32 = {
    <l:Expr> "+" <r:Term> => l + r,
    Term,
};
```

Who is using it?
- `LALRPOP` is itself implemented in LALRPOP.
- `Gluon` is a statically typed functional programming language.
- `RustPython` is Python 3.5+ rewritten in Rust

<!-- end_slide -->

Lalrpop v.s. parser combinators
---

<!-- skip_slide -->

only for basel-rust

<!-- end_slide -->

Tokio for concurrent runtime
---

High-throughput: one system process handles +10,000 tasks (DB + remote jobs).

Tokio provides an async runtime for running async/await tasks.

- Multi-threading runtime: spreads tasks across a work-stealing thread pool.
- Current-thread runtime: runs tasks on a single thread.
- Structured concurrency: ensures spawned tasks are managed, cancelled properly.
- Integrates with I/O, timers, and synchronization primitives.

<!-- end_slide -->

PyO3 for FFI with Python
---

Foreign Function Interface (FFI) is mechanism to call functions across languages.

PyO3 is used for 

- Calling Rust code in Python (as extension modules).
- Calling Python code in Rust (via embedded Python interpreter).

Projects using PyO3

- `Polars`: blazing-fast DataFrame library alternative of pandas (Rust core, Python bindings).
- `Pydantic v2`: Python data validation & settings management (core rewritten in Rust).
- ...

<!-- end_slide -->

Explain how pyo3 works
---

<!-- skip_slide -->

only for basel rust

- FFI, C-ABI
- maturin

<!-- end_slide -->

miette for fancy error report
---

`miette` is beautiful error reporting for Rust.

<!-- pause -->

```c
function foo(a: Int, b: Int) -> String {
    return "oxiida";
}
// passing wrong arg; type error!
a = "8";
foo(a, 4);
```

```bash +exec
./oxiida run type-error.ox
```

<!-- pause -->

How it popped?

```rust
if para_typsrc.typ != arg_typsrc.typ {
    return Err(miette::miette!(
        severity = Severity::Error,
        code = "typecheck::expr::fncall::argstypunmatch",
        labels = vec![
            LabeledSpan::at(param_typsrc.source.range(), "expect"),
            LabeledSpan::at(arg_typsrc.source.range(), "infered from",),
            LabeledSpan::at(arg.range(), "got"),
        ],
        "pass wrong type to param '{}'", param_name,
    )
    .with_source_code(self.source_code.to_owned()))?;
}
```

<!-- end_slide -->

miette, interop with thiserror and anyhow
---

only for basel rust
<!-- skip_slide -->

<!-- end_slide -->

<!-- jump_to_middle -->

But... ("what if you leave the team?")
---
<!-- end_slide -->

Join us! Get rusty!
---

<!-- column_layout: [5, 3] -->

<!-- column: 0 -->

![image:width:90%](./rs4rse-flyer.png)

<!-- column: 1 -->

- Jusong Yu (PSI)
- David Perl (PSI)
- Stefan Milosavljevic (SDSC)
- Gabriel Nützi (SDSC)

In PSI, we have in person meetup event every Wednesday!

Beginner friendly. Not just Rust.

<!-- end_slide -->

<!-- jump_to_middle -->

Ack:

- Alexander Goscinski
- Giovanni Pizzi
- Rust Berlin
- Rust Basel
- AiiDA team

---

Thanks!

