# how to present

The slides are made by [`presenterm`](https://mfontanini.github.io/presenterm/introduction.html)

To show slides, in the folder and run:

```console
presenterm -x main.md
```
