function foo(a: Int, b: Int) -> String {
    return "oxiida";
}
// passing wrong arg; type error!
a = "8";
foo(a, 4);
